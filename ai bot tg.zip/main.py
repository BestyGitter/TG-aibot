import telebot
from logic import get_class

bot = telebot.TeleBot("8110045242:AAEdOevz-FgKl2MRUmcyXQ24_2MVP6FJ6qQ")
lan = "eng"


@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(message, "Привет, человек! Я готов классифицировать твои фото.")

@bot.message_handler(func=lambda message:True)
def lang(message):
    global lan
    text = message.text.split()
    print(text)
    if text[0] == "/lang":
        lan = text[1]
        print(lan)
    if lan == "ru":
        bot.reply_to(message, f"Ваш язык изменён на: {lan}")
    else:
        bot.reply_to(message, f"Your languange change to: {lan}")

@bot.message_handler(content_types=['photo'])
def photo(message):
    photos = message.photo
    file_info = bot.get_file(photos[-1].file_id)
    file_name = file_info.file_path.split('/')[-1]
    #
    downloaded_file = bot.download_file(file_info.file_path)
    with open('photo', 'wb') as new_file:
        new_file.write(downloaded_file)
    #
    print(file_name)
    model_path = "keras_model.h5"
    labels_path = "labels.txt"
    image_path = "photo"
    result, percent = get_class(model_path, labels_path, image_path)
    if result == 0:
        if lan == "ru":
            result = "Андроид"
        else:
            result = "Android"
    else:
        if lan == "ru":
            result = "Айфон"
        else:
            result = "Iphone"
    if percent < 0.67:
        if lan == "ru":
            bot.reply_to(message, "Я не могу определить, сори")
        else:
            bot.reply_to(message, "I can`t give you correct unswer the question, sorry")
    else:
        bot.reply_to(message, result)

bot.infinity_polling()